package weka.classifiers.trees;

import weka.classifiers.AbstractClassifier;
import weka.classifiers.RandomizableClassifier;
import weka.core.Instance;
import weka.core.Instances;

import java.util.Random;

public class RandomClassClassifier extends RandomizableClassifier {

    private int selectedClass = 0;
    @Override
    public void buildClassifier(Instances data) throws Exception {
        Random r = new Random(getSeed());
        selectedClass = r.nextInt(data.classAttribute().numValues());
    }

    @Override
    public double classifyInstance(Instance instance) throws Exception {
        return selectedClass;
    }
}
